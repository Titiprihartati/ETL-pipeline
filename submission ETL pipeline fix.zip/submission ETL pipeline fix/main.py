import pandas as pd
from utils.extract import extract_data
from utils.transform import transform_data
from utils.load import load_to_csv
import logging
from datetime import datetime

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('etl_pipeline.log'),
        logging.StreamHandler()
    ]
)

def run_etl_pipeline():
    """Main function to execute the ETL pipeline"""
    try:
        # Extraction phase
        logging.info("Starting data extraction...")
        start_time = datetime.now()
        
        raw_df = extract_data()
        if raw_df.empty:
            raise ValueError("No data was extracted")
        logging.info(f"Successfully extracted {len(raw_df)} records")
        
        # Transformation phase
        logging.info("Starting data transformation...")
        transformed_df = transform_data(raw_df)
        if transformed_df.empty:
            raise ValueError("No data after transformation")
        logging.info(f"Successfully transformed {len(transformed_df)} records")
        
        # Loading phase
        logging.info("Starting data loading...")
        if load_to_csv(transformed_df):
            logging.info("Data successfully loaded to CSV")
        else:
            raise RuntimeError("Failed to load data to CSV")
            
        end_time = datetime.now()
        duration = end_time - start_time
        logging.info(f"ETL pipeline completed successfully in {duration.total_seconds():.2f} seconds")
        
    except Exception as e:
        logging.error(f"ETL pipeline failed: {str(e)}")
        raise

if __name__ == "__main__":
    run_etl_pipeline()
